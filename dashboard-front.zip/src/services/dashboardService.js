import api from './api';

export async function fetchAdminNews() {
  const response = await api.get('/api/admin/news');
  return response.data;
}

export async function createNews(payload) {
  const response = await api.post('/api/admin/news', payload);
  return response.data;
}

export async function updateNews(id, payload) {
  const response = await api.put(`/api/admin/news/${id}`, payload);
  return response.data;
}

export async function deleteNews(id) {
  const response = await api.delete(`/api/admin/news/${id}`);
  return response.data;
}

export async function fetchHomeContent() {
  const response = await api.get('/api/admin/home');
  return response.data;
}

export async function fetchHomeSummary() {
  const response = await api.get('/api/admin/home/summary');
  return response.data;
}

export async function updateHomeContent(payload) {
  const response = await api.put('/api/admin/home', payload);
  return response.data;
}

export async function updateHomeStats(items) {
  const response = await api.put('/api/admin/home/stats', { items });
  return response.data;
}

export async function updateHomeDifferentials(items) {
  const response = await api.put('/api/admin/home/differentials', { items });
  return response.data;
}

export async function updateHomeAboutCards(items) {
  const response = await api.put('/api/admin/home/about-cards', { items });
  return response.data;
}

export async function updateHomeServiceCards(items) {
  const response = await api.put('/api/admin/home/service-cards', { items });
  return response.data;
}

export async function updateHomePortfolioItems(items) {
  const response = await api.put('/api/admin/home/portfolio-items', { items });
  return response.data;
}

export async function fetchMedia() {
  const response = await api.get('/api/media');
  return response.data;
}

export async function uploadMedia(formData) {
  const response = await api.post('/api/media/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  });
  return response.data;
}

export async function deleteMediaItem(id) {
  const response = await api.delete(`/api/media/${id}`);
  return response.data;
}

export const fetchAboutContent = async () => {
  const response = await api.get('/api/admin/about');
  return response.data;
};

export const updateAboutContent = async (payload) => {
  const response = await api.put('/api/admin/about', payload);
  return response.data;
};

export const updateAboutHighlights = async (items) => {
  const response = await api.put('/api/admin/about/highlights', { items });
  return response.data;
};

export const updateAboutTimeline = async (items) => {
  const response = await api.put('/api/admin/about/timeline', { items });
  return response.data;
};

export const updateAboutValues = async (items) => {
  const response = await api.put('/api/admin/about/values', { items });
  return response.data;
};

export async function fetchAdminUsers() {
  const response = await api.get('/api/admin/users');
  return response.data;
}

export async function createAdminUser(payload) {
  const response = await api.post('/api/admin/users', payload);
  return response.data;
}

export async function updateAdminUser(id, payload) {
  const response = await api.put(`/api/admin/users/${id}`, payload);
  return response.data;
}

export async function fetchComplaints(params = {}) {
  const response = await api.get('/api/admin/complaints', { params });
  return response.data;
}

export async function fetchComplaintById(id) {
  const response = await api.get(`/api/admin/complaints/${id}`);
  return response.data;
}

export async function updateComplaintStatus(id, payload) {
  const response = await api.put(`/api/admin/complaints/${id}/status`, payload);
  return response.data;
}


export async function fetchCandidates(params = {}) {
  try {
    const response = await api.get('/api/admin/careers/applications', { params });
    return response.data;
  } catch (error) {
    if (error?.response?.status === 404) {
      const fallback = await api.get('/api/admin/candidates', { params });
      return fallback.data;
    }
    throw error;
  }
}

export async function fetchCandidateById(id) {
  try {
    const response = await api.get(`/api/admin/careers/applications/${id}`);
    return response.data;
  } catch (error) {
    if (error?.response?.status === 404) {
      const fallback = await api.get(`/api/admin/candidates/${id}`);
      return fallback.data;
    }
    throw error;
  }
}

export async function fetchSystemSettings() {
  const response = await api.get('/api/admin/settings');
  return response.data;
}

export async function updateSystemSettings(payload) {
  const response = await api.put('/api/admin/settings', payload);
  return response.data;
}


function hasPaymentAttachments(payload) {
  return Boolean(payload?.invoiceAttachment || payload?.boletoAttachment);
}

function toPaymentRequestFormData(payload) {
  const formData = new FormData();
  const { invoiceAttachment, boletoAttachment, ...cleanPayload } = payload;
  formData.append('payload', JSON.stringify(cleanPayload));
  if (invoiceAttachment) formData.append('invoiceAttachment', invoiceAttachment);
  if (boletoAttachment) formData.append('boletoAttachment', boletoAttachment);
  return formData;
}

function toBulkPaymentRequestFormData(items) {
  const formData = new FormData();
  const cleanItems = items.map(({ invoiceAttachment, boletoAttachment, ...item }, index) => {
    if (invoiceAttachment) formData.append(`invoiceAttachment_${index}`, invoiceAttachment);
    if (boletoAttachment) formData.append(`boletoAttachment_${index}`, boletoAttachment);
    return item;
  });
  formData.append('payload', JSON.stringify({ items: cleanItems }));
  return formData;
}

export async function fetchPaymentRequests(params = {}) {
  const response = await api.get('/api/admin/payment-requests', { params });
  return response.data;
}

export async function createPaymentRequest(payload) {
  const body = hasPaymentAttachments(payload) ? toPaymentRequestFormData(payload) : payload;
  const config = hasPaymentAttachments(payload) ? { headers: { 'Content-Type': 'multipart/form-data' } } : undefined;
  const response = await api.post('/api/admin/payment-requests', body, config);
  return response.data;
}

export async function updatePaymentRequest(id, payload) {
  const body = hasPaymentAttachments(payload) ? toPaymentRequestFormData(payload) : payload;
  const config = hasPaymentAttachments(payload) ? { headers: { 'Content-Type': 'multipart/form-data' } } : undefined;
  const response = await api.put(`/api/admin/payment-requests/${id}`, body, config);
  return response.data;
}

export async function deletePaymentRequest(id) {
  const response = await api.delete(`/api/admin/payment-requests/${id}`);
  return response.data;
}

export async function createPaymentRequestsBulk(items) {
  const body = items.some(hasPaymentAttachments) ? toBulkPaymentRequestFormData(items) : { items };
  const config = items.some(hasPaymentAttachments) ? { headers: { 'Content-Type': 'multipart/form-data' } } : undefined;
  const response = await api.post('/api/admin/payment-requests/bulk', body, config);
  return response.data;
}


export async function fetchPaymentRequestQueueStatus(jobId) {
  const params = jobId ? { jobId } : {};
  const response = await api.get('/api/admin/payment-requests/queue/status', { params });
  return response.data;
}

export async function searchPaymentSuppliers(q) {
  const response = await api.get('/api/admin/payment-requests/suppliers', { params: { q } });
  return response.data;
}

export async function downloadPaymentRequestsPdf(ids) {
  const query = Array.isArray(ids) ? ids.join(',') : String(ids);
  const response = await api.get('/api/admin/payment-requests/pdf', {
    params: { ids: query },
    responseType: 'blob'
  });
  return response.data;
}

export async function downloadPaymentRequestsXlsx(ids) {
  const query = Array.isArray(ids) ? ids.join(',') : String(ids);
  const response = await api.get('/api/admin/payment-requests/xlsx', {
    params: { ids: query },
    responseType: 'blob'
  });
  return response.data;
}

export async function fetchPaymentRequestSchedules(params = {}) {
  const response = await api.get('/api/admin/payment-requests/schedules', { params });
  return response.data;
}

export async function createPaymentRequestSchedule(payload) {
  const response = await api.post('/api/admin/payment-requests/schedules', payload);
  return response.data;
}

export async function updatePaymentRequestSchedule(id, payload) {
  const response = await api.put(`/api/admin/payment-requests/schedules/${id}`, payload);
  return response.data;
}

export async function deletePaymentRequestSchedule(id) {
  const response = await api.delete(`/api/admin/payment-requests/schedules/${id}`);
  return response.data;
}

export async function searchCostCenters(q = '', includeInactive = false) {
  const response = await api.get('/api/admin/cost-centers', {
    params: { q, search: q, includeInactive }
  });
  return response.data;
}

export async function createCostCenter(payload) {
  const response = await api.post('/api/admin/cost-centers', payload);
  return response.data;
}

export async function updateCostCenter(id, payload) {
  const response = await api.put(`/api/admin/cost-centers/${id}`, payload);
  return response.data;
}

export async function deleteCostCenter(id) {
  const response = await api.delete(`/api/admin/cost-centers/${id}`);
  return response.data;
}


export async function fetchCareerJobs(params = {}) {
  const response = await api.get('/api/admin/careers/jobs', { params });
  return response.data;
}

export async function createCareerJob(payload) {
  const response = await api.post('/api/admin/careers/jobs', payload);
  return response.data;
}

export async function updateCareerJob(id, payload) {
  const response = await api.put(`/api/admin/careers/jobs/${id}`, payload);
  return response.data;
}

export async function deleteCareerJob(id) {
  const response = await api.delete(`/api/admin/careers/jobs/${id}`);
  return response.data;
}

export async function sendCandidateMessage(id, payload) {
  const response = await api.post(`/api/admin/careers/applications/${id}/message`, payload);
  return response.data;
}
